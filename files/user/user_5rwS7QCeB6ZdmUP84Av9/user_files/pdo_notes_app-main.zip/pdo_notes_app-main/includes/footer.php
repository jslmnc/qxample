<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js
"></script>
<!-- Material Design JavaScript -->
<script src="js/material.js"></script>
<script src="js/ripples.js"></script>
<!-- Custom Javascript -->
<script src="js/app.js"></script>
<script> $.material.init(); </script>
</html>