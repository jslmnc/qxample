<div class="container">
    <div class="row">
        <div class="col-md-10 mx-auto">
            <div class="card">
                <div class="card-header bg-white">
                    <h3>Notes</h3>
                </div>
                <div class="card-body">
                    <table class="table table-hover table-responsive">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Body</th>
                                <th>Status</th>
                                <th>Add</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="task-list">
                        
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>