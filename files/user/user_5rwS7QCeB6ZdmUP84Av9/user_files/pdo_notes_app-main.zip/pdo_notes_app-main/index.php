<?php include("includes/header.php");?>
<?php include("includes/tasks.php");?>
<?php include("includes/footer.php");?>