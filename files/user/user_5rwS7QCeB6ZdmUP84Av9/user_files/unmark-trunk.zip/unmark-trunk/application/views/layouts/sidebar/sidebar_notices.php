<?php

// Add any notification you want to appear in the sidebar here...


?>

<div class="sidebar-block">
    <div class="sidebar-inner">
		<p><?php echo unmark_phrase('For usage tips <a target="_blank" rel="noopener noreferrer" href="https://twitter.com/unmarkit">follow us on Twitter</a>!')?></p>
    </div>
</div>
