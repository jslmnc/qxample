            </div>
            <div class="sidebar-content"><?php $this->load->view('layouts/sidebar'); ?></div>
        </div>

        <div class="mobile-close-overlay" id="navigation-close-overlay"></div>
        <div class="mobile-close-overlay" id="sidebar-close-overlay"></div>

    </div> <!-- end main-wrapper -->
</div> <!-- end unmark-wrapper -->
</main> <!-- end unmark-stage -->

<?php $this->load->view('layouts/footer_scripts')?>

</body>
</html>
