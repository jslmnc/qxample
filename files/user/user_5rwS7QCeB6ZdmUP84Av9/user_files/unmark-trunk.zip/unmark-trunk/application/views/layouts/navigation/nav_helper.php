<li class="panel-marks"><a href="/marks"><?php echo unmark_phrase('All Marks') ?></a></li>
<li class="panel-label"><a rel="260" href="#panel-label"><?php echo unmark_phrase('Labels') ?></a></li>
<li class="panel-timeline"><a rel="260" href="#panel-timeline"><?php echo unmark_phrase('Timeline') ?></a></li>
<li class="panel-search"><a rel="260" href="#panel-search"><?php echo unmark_phrase('Search') ?></a></li>
<li class="panel-search"><a rel="260" href="/marks/archive"><?php echo unmark_phrase('Archives') ?></a></li>
