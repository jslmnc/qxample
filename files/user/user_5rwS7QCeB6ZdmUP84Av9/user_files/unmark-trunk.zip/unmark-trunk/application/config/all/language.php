<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// Language to use
$config['default_language'] = 'english';

// Supported languages
$config['supported_languages'] = array(
    'english' => 'en_US',
    'polish' => 'pl_PL',
    'simple_chinese' => 'zh_CN'
);
