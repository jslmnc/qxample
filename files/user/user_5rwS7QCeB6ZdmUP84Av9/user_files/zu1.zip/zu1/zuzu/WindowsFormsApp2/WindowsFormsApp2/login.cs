﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


using System.Data.SqlClient;

namespace WindowsFormsApp2
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void login_Load(object sender, EventArgs e)
        {
          //  string s = "";
         //   s = "Select * from login";
        }

        private void button2_Click(object sender, EventArgs e)
        {


            if (user.Text == "" || pass.Text == "")
            {
                MessageBox.Show("please fill up missing fields");
            }
            else
            {
                try
                {
                    connection.connection.DB();


                    string a = "select * from signup where username= '" + user.Text + "' and password='" + pass.Text + "'";
                    string b = "select * from signup where username= '" + user.Text + "'";
                    string c = "select * from signup where password= '" + pass.Text + "'";
                    SqlCommand commanda = new SqlCommand(a, connection.connection.conn);
                    SqlCommand commandb = new SqlCommand(b, connection.connection.conn);
                    SqlCommand commandc = new SqlCommand(c, connection.connection.conn);
                    function.function.datareader = commanda.ExecuteReader();
                    function.function.datareader2 = commandb.ExecuteReader();
                    function.function.datareader3 = commandc.ExecuteReader();

                    

                    


                    if (function.function.datareader2.Read()==false && function.function.datareader2.Read() ==false)
                    {

                        MessageBox.Show("account doesnt exist!");
                    }

                    

                    else
                    {



                        if (function.function.datareader.Read())
                        {
                            dashboard d = new dashboard();

                            d.Show();
                            this.Hide();

                        }

                        else
                        {
                            MessageBox.Show("wrong password");

                        }

                    }


                    connection.connection.conn.Close();
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

            /*/
           
            if (user.Text == "" || pass.Text == "")
            {
                MessageBox.Show("enter missing fields");

            }
            else
            {
                try
                {

                    connection.connection.DB();

                    string us = "select * from signup where username ='" + user.Text + "' and password ='"+pass.Text+"'";
                    string us1 = "select * from signup where username ='" + user.Text+ "'";
                    string pa = "select * from signup where  password ='" + pass.Text + "'";
                    SqlDataAdapter d = new SqlDataAdapter(us, connection.connection.conn);
                    SqlDataAdapter d1= new SqlDataAdapter(us1, connection.connection.conn);
                    SqlDataAdapter ee = new SqlDataAdapter(pa, connection.connection.conn);
                    DataTable dt = new DataTable();
                    DataTable dt2 = new DataTable();
                    DataTable dt1 = new DataTable();

                    
                    d.Fill(dt);
                    d1.Fill(dt1);
                    ee.Fill(dt2);

                    if (dt1.Rows.Count!=1&&dt2.Rows.Count!=1)
                    {
                      
                        MessageBox.Show("account doesnt exist!");
                    }

                    else 
                    {

                        if (dt2.Rows.Count == 1)
                        {
                            
                            dashboard c = new dashboard();
                            c.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("wrong password");

                        }


                    }

                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                connection.connection.conn.Close();

            }

    /*/


        }

        public void clear()
        {
            user.Clear();
            pass.Clear();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            signup v = new signup();

            v.Show();
            this.Hide();




        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            changepassword f = new changepassword();

            f.Show();
            this.Hide();




        }

        private void user_TextChanged(object sender, EventArgs e)
        {

        }

        private void x_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Close();
        }

        private void button2_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (user.Text == "" || pass.Text == "")
            {
                MessageBox.Show("enter missing fields");

            }



            else
            {
                try
                {

                    connection.connection.DB();

                    string v = "select * from signup where username ='" + user.Text + "' and password ='" + pass.Text + "'";

                    SqlDataAdapter d = new SqlDataAdapter(v, connection.connection.conn);
                    DataTable dt = new DataTable();

                    d.Fill(dt);

                    if (dt.Rows.Count == 1)
                    {

                        dashboard c = new dashboard();
                        c.Show();
                        this.Hide();

                    }


                    else
                    {
                        MessageBox.Show("wrong username or password!");
                    }

                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                connection.connection.conn.Close();

            }
            
        }

        private void user_KeyPress(object sender, KeyPressEventArgs e)
        {

            
            
        }

        private void pass_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }
    }


}
