﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp2
{
    public partial class changepassword : Form
    {
        public changepassword()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            connection.connection.DB();

            string v = "select * from signup where username ='" + usern.Text + "'";

            // SqlDataAdapter data = new SqlDataAdapter(v, connection.connection.conn);
            //DataTable dt = new DataTable();


            SqlCommand st = new SqlCommand(v, connection.connection.conn);
            function.function.datareader = st.ExecuteReader();

            //  data.Fill(dt);


            //function.function.datagridfill(v, data);

            if (usern.Text == "" || oldpass.Text == "" || newpass.Text == "" || connewp.Text == "")
            {
                MessageBox.Show("Please fill up missing fields!");
            }
            //dt.Rows.Count !=1

            else if (function.function.datareader.Read())
            {
                


                try
                {
                    if (newpass.Text != connewp.Text)
                    {
                        MessageBox.Show("Password did not match!");
                    }

                    else
                    {
                        //create queries-- adding
                        string gen = " Update signup set password = " + "'" + newpass.Text + "' where username ='" + usern.Text + "'";
                        SqlCommand command = new SqlCommand(gen, connection.connection.conn);
                        command.ExecuteNonQuery();
                        //promt the connection string
                        MessageBox.Show("Password changed successfully!");
                        //close the connection
                        //changepassword_Load(sender, e);
                        clear();
                    }
                }


               catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                connection.connection.conn.Close();

            }


        

            //  if (dt.Rows.Count == 1)
            else
            {
                MessageBox.Show("username doesnt exist");
            }
        }


 


        public void clear()
        {
            oldpass.Clear();
            newpass.Clear();
            connewp.Clear();
            usern.Clear();

        }

        private void passw_TextChanged(object sender, EventArgs e)
        {

        }

        private void conpassw_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }
    }
}
