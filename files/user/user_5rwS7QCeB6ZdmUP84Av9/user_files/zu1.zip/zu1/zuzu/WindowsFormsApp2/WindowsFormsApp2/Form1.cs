﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
//using System.Windows.Forms;


namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                connection.connection.DB();
                //call the connectrion

                //create queries-- adding
                string gen="Insert into customer(customerid,customername)values("+textBox1.Text+",'"+textBox2.Text+"')";
                SqlCommand command = new SqlCommand(gen, connection.connection.conn);
                command.ExecuteNonQuery();
                //promt the connection string
                MessageBox.Show("Successfully saved");
                //close the connection


               



                Form1_Load(sender, e);
                connection.connection.conn.Close();
                clear();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void clear()
        {
            textBox1.Clear();
            textBox2.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'customerDataSet.customer' table. You can move, or remove it, as needed.
         //  this.customerTableAdapter.Fill(this.customerDataSet.customer);
            string s = "";
            s = "Select * from customer order by customerid asc";
            function.function.datagridfill(s, dataGridView1);




        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {


            try
            {
                connection.connection.DB();
                //call the connectrion

                //create queries-- adding
                string gen =" Update customer set customername = "+ "'"+textBox2.Text+"' where customerid="+textBox1.Text + "";
                SqlCommand command = new SqlCommand(gen, connection.connection.conn);
                command.ExecuteNonQuery();
                //promt the connection string
                MessageBox.Show("Successfully updated");
                //close the connection

                Form1_Load(sender, e);
               
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            connection.connection.conn.Close();



        }
        private void button3_Click(object sender, EventArgs e)
        {
            //connection.connection.conn.Open();
            connection.connection.DB();
            String st = "DELETE customer WHERE customerid =" + textBox1.Text;


            SqlCommand command = new SqlCommand(st, connection.connection.conn);
            try
            {

                command.ExecuteNonQuery();
                MessageBox.Show("Deleted!");
                Form1_Load(sender, e);
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            connection.connection.conn.Close();

        }

        private void DataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {

           

       
            try
            {
                connection.connection.DB();
                String gen = "Select * from customer where customerid = " + dataGridView1.CurrentRow.Cells[0].Value+"";
                SqlCommand st = new SqlCommand(gen, connection.connection.conn);
                function.function.datareader = st.ExecuteReader();

                if(function.function.datareader.Read())
                {
                    textBox1.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                    textBox2.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                }
              
               // Form1_Load(sender, e);
               // clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            connection.connection.conn.Close();


        }

        private void TextBox3_TextChanged(object sender, EventArgs e)
        {
            try
            {
                connection.connection.DB();

                string gen = " Select * from customer where customerid like " + "'" + txtsearch.Text + "%' or customername like '" + txtsearch.Text + "%'";
                function.function.datagridfill(gen, dataGridView1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            
            txtsearch.Text = "";

           
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
