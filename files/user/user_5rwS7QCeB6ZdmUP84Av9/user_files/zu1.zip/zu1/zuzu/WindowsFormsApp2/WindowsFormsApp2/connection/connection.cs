﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Windows.Forms;



namespace WindowsFormsApp2.connection
{
    class connection
    {
        public static SqlConnection conn;
       
        public static string dbconnect = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\SALAMANCA\\Downloads\\zu1\\zuzu\\WindowsFormsApp2\\WindowsFormsApp2\\customer.mdf;Integrated Security=True; MultipleActiveResultSets=True;";

        public static void DB()
        {
            try
            {
                conn = new SqlConnection(dbconnect);
                conn.Open();
            }
            catch(Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
       



    }
}
