﻿namespace WindowsFormsApp2
{


    partial class customerDataSet
    {
    }
}

namespace WindowsFormsApp2.customerDataSetTableAdapters {
    
    
    public partial class customerTableAdapter {
    }
}
