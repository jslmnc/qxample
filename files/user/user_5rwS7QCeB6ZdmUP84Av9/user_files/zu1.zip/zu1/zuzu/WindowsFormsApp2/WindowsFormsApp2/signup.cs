﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;




namespace WindowsFormsApp2
{
    public partial class signup : Form
    {
        public signup()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {


            connection.connection.DB();

            string v = "select * from signup where username ='" + usern.Text + "'";

            //SqlDataAdapter d = new SqlDataAdapter(v, connection.connection.conn);
            // DataTable dt = new DataTable();

            SqlCommand st = new SqlCommand(v, connection.connection.conn);
            function.function.datareader = st.ExecuteReader();



            if (name.Text == "" || usern.Text == "" || email.Text == "" || passw.Text == "" || conpassw.Text == "")
            {
                MessageBox.Show("Please fill up missing fields!");
            }


            else if (function.function.datareader.Read())
            {

                MessageBox.Show("username already exist");

            }

            else
            {
                try
                {

                    //  function.function.datagridfill(, );

                    // d.Fill(dt);

                    //call the connectrion
                    // if (dt.Rows.Count == 1)

                    if (passw.Text == conpassw.Text)
                    {
                        //create queries-- adding
                        string gen = "insert into signup(name,username,email,password)values('" + name.Text + "','" + usern.Text + "','" + email.Text + "','" + passw.Text + "')";
                        SqlCommand command = new SqlCommand(gen, connection.connection.conn);

                        command.ExecuteNonQuery();
                        //promt the connection string
                        MessageBox.Show("Registered successfuly");
                        clear();


                    }

                    else
                    {
                        MessageBox.Show("password did not match");
                    }



                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
                //close the connection
                connection.connection.conn.Close();


            }
        }



        public void clear()
        {
            name.Clear();
            usern.Clear();
            email.Clear();
            passw.Clear();
            conpassw.Clear();
        }

        private void signup_Load(object sender, EventArgs e)
        {

        }

        private void email_TextChanged(object sender, EventArgs e)
        {

        }

        private void passw_TextChanged(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            login l = new login();
            l.Show();
            this.Hide();
        }
    }
}
