﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace WindowsFormsApp2.function
{
    class function

    {

        public static SqlDataReader datareader= null;
        public static SqlDataReader datareader2 = null;
        public static SqlDataReader datareader3= null;

        public static void datagridfill(string q, DataGridView dgv)
        {

            
            try
            {
                connection.connection.DB();

                

                DataTable dt = new DataTable();
                SqlDataAdapter data = null;
                SqlCommand command = new SqlCommand(q, connection.connection.conn);
                data = new SqlDataAdapter(command);
                data.Fill(dt);
               
                dgv.DataSource = dt;
                connection.connection.conn.Close();

                /*/
                SqlDataAdapter d1= new SqlDataAdapter();
                SqlDataAdapter d2 = new SqlDataAdapter();
                SqlDataAdapter d3 = new SqlDataAdapter();
                DataTable dt1= new DataTable();
                DataTable dt2 = new DataTable();
                DataTable dt3 = new DataTable();


                d1.Fill(dt1);
                d2.Fill(dt2);
                d3.Fill(dt3);

    /*/
            }

            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

      
    }
}
