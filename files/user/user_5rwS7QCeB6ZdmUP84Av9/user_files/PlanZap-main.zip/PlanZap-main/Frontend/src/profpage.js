import React from "react";
import "./CSSComponents/App.css";

const Profile = () => {
  return (
    <div className="profpage">
      <h1>This is the profile page</h1>
    </div>
  );
};

export default Profile;
