import { createContext } from "react";

export const usercontext = createContext({});
