import React from "react";
import "./CSSComponents/App.css";

const Pgraph = () => {
  return (
    <div className="profpage">
      <h1>This is the Performance Page</h1>
    </div>
  );
};

export default Pgraph;
